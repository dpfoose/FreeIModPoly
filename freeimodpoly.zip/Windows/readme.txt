How to use the Windows binary:
usage:
freeimodpoly poly_order max_it threshold infile outfile outtype transpose

poly_order and max_it are integers for polynomial order and maximum iterations
threshold is the threshold for error. For 0.95% confidence use 0.05
infile is the input file path in an armadillo-parsable format
    (tab, space or comma delimited, or armadillo binary)
outfile is the output file name trunk, without the extension
outtype is either txt for tab-delimited text or csv for comma-delimited text
transpose is either 0 or nonzero. If nonzero, this tells the program that spectra are in rows.

The input must have atleast two columns (or rows of transpose!=0). The first is the abscissa (x-axis).
Subsequent columns (rows) are the spectra to be fitted.

If the input has only one spectrum, the output is one file (outfile.outtype), containing
abscissa, baseline and corrected spectrum. The number of iterations and final value
of the error parameter are reported to the command line.

If the input has multiple spectra, the output is three files (outfile_bl.outtype,
outfile_cs.outtype, outfile_er.outtype). bl, cs, and er refer to baselines,
corrected spectra and error, respectively. Er is a matrix with same number of rows
as infile has spectra. The first column is the number final error value, the second column
is whether or not the fit converged. bl and cs contain the abscissa as the first column.

Dan Foose
2015-07-31
